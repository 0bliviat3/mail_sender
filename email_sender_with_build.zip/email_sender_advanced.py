import tkinter as tk
from tkinter import ttk, filedialog, messagebox, scrolledtext
import pandas as pd
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from email.mime.base import MIMEBase
from email import encoders
import os
import json
import time
import re

class AdvancedEmailSenderApp:
    def __init__(self, root):
        self.root = root
        self.root.title("대량 맞춤 메일 발송 프로그램 (고급)")
        self.root.geometry("950x750")
        
        self.config_file = "email_config.json"
        self.load_config()
        
        self.recipients_data = None
        
        self.create_widgets()
        
    def create_widgets(self):
        # 메인 프레임
        main_frame = ttk.Frame(self.root, padding="10")
        main_frame.grid(row=0, column=0, sticky=(tk.W, tk.E, tk.N, tk.S))
        
        # 1. 발신자 설정 섹션
        sender_frame = ttk.LabelFrame(main_frame, text="발신자 설정", padding="10")
        sender_frame.grid(row=0, column=0, columnspan=2, sticky=(tk.W, tk.E), pady=5)
        
        ttk.Label(sender_frame, text="발신 이메일:").grid(row=0, column=0, sticky=tk.W, pady=2)
        self.sender_email = ttk.Entry(sender_frame, width=40)
        self.sender_email.grid(row=0, column=1, sticky=(tk.W, tk.E), pady=2, padx=5)
        self.sender_email.insert(0, self.config.get('sender_email', ''))
        
        ttk.Label(sender_frame, text="비밀번호:").grid(row=1, column=0, sticky=tk.W, pady=2)
        self.sender_password = ttk.Entry(sender_frame, width=40, show="*")
        self.sender_password.grid(row=1, column=1, sticky=(tk.W, tk.E), pady=2, padx=5)
        
        ttk.Label(sender_frame, text="SMTP 서버:").grid(row=2, column=0, sticky=tk.W, pady=2)
        smtp_frame = ttk.Frame(sender_frame)
        smtp_frame.grid(row=2, column=1, sticky=(tk.W, tk.E), pady=2, padx=5)
        
        self.smtp_server = ttk.Entry(smtp_frame, width=25)
        self.smtp_server.pack(side=tk.LEFT)
        self.smtp_server.insert(0, self.config.get('smtp_server', 'smtp.gmail.com'))
        
        ttk.Label(smtp_frame, text="포트:").pack(side=tk.LEFT, padx=(10, 5))
        self.smtp_port = ttk.Entry(smtp_frame, width=8)
        self.smtp_port.pack(side=tk.LEFT)
        self.smtp_port.insert(0, self.config.get('smtp_port', '587'))
        
        ttk.Button(sender_frame, text="Gmail 설정 가이드", 
                  command=self.show_gmail_guide).grid(row=3, column=1, sticky=tk.W, pady=5, padx=5)
        
        # 2. 수신자 데이터 섹션
        recipient_frame = ttk.LabelFrame(main_frame, text="수신자 데이터", padding="10")
        recipient_frame.grid(row=1, column=0, columnspan=2, sticky=(tk.W, tk.E), pady=5)
        
        ttk.Button(recipient_frame, text="📁 Excel/CSV 파일 불러오기", 
                  command=self.load_recipients).grid(row=0, column=0, pady=5, padx=5)
        
        self.file_label = ttk.Label(recipient_frame, text="파일이 선택되지 않았습니다.", 
                                    foreground="gray")
        self.file_label.grid(row=0, column=1, sticky=tk.W, padx=5)
        
        ttk.Button(recipient_frame, text="📋 데이터 미리보기", 
                  command=self.preview_data).grid(row=1, column=0, pady=5, padx=5)
        
        ttk.Button(recipient_frame, text="📝 샘플 파일 생성", 
                  command=self.create_sample_file).grid(row=1, column=1, sticky=tk.W, pady=5, padx=5)
        
        # 3. 메일 내용 섹션
        content_frame = ttk.LabelFrame(main_frame, text="메일 내용", padding="10")
        content_frame.grid(row=2, column=0, columnspan=2, sticky=(tk.W, tk.E, tk.N, tk.S), pady=5)
        
        ttk.Label(content_frame, text="메일 제목:").grid(row=0, column=0, sticky=tk.W, pady=2)
        self.subject = ttk.Entry(content_frame, width=70)
        self.subject.grid(row=0, column=1, sticky=(tk.W, tk.E), pady=2, padx=5)
        
        ttk.Label(content_frame, text="메일 본문 템플릿:").grid(row=1, column=0, sticky=(tk.N, tk.W), pady=2)
        
        help_frame = ttk.Frame(content_frame)
        help_frame.grid(row=1, column=1, sticky=tk.W, padx=5)
        ttk.Label(help_frame, text="{{컬럼명}} 형식으로 변수 삽입 가능", 
                 foreground="blue", font=("", 8)).pack(side=tk.LEFT)
        ttk.Button(help_frame, text="변수 확인", 
                  command=self.show_variables).pack(side=tk.LEFT, padx=5)
        
        self.body_text = scrolledtext.ScrolledText(content_frame, width=70, height=10)
        self.body_text.grid(row=2, column=0, columnspan=2, pady=5, padx=5, sticky=(tk.W, tk.E, tk.N, tk.S))
        self.body_text.insert(1.0, 
            "안녕하세요, {{이름}}님\n\n"
            "메일 내용을 작성해주세요.\n"
            "Excel 파일의 모든 컬럼을 {{컬럼명}} 형식으로 사용할 수 있습니다.\n\n"
            "감사합니다.")
        
        # HTML 모드 체크박스
        self.html_mode = tk.BooleanVar(value=False)
        ttk.Checkbutton(content_frame, text="HTML 형식 사용", 
                       variable=self.html_mode).grid(row=3, column=0, columnspan=2, sticky=tk.W, pady=5, padx=5)
        
        # 4. 전송 옵션 섹션
        option_frame = ttk.LabelFrame(main_frame, text="전송 옵션", padding="10")
        option_frame.grid(row=3, column=0, columnspan=2, sticky=(tk.W, tk.E), pady=5)
        
        self.attach_files = tk.BooleanVar(value=False)
        ttk.Checkbutton(option_frame, text="첨부파일 사용 (Excel '첨부파일' 컬럼)", 
                       variable=self.attach_files).grid(row=0, column=0, sticky=tk.W, pady=2)
        
        self.test_mode = tk.BooleanVar(value=True)
        ttk.Checkbutton(option_frame, text="테스트 모드 (실제 전송 안함)", 
                       variable=self.test_mode).grid(row=1, column=0, sticky=tk.W, pady=2)
        
        # 전송 속도 조절
        speed_frame = ttk.Frame(option_frame)
        speed_frame.grid(row=2, column=0, sticky=tk.W, pady=5)
        ttk.Label(speed_frame, text="메일 간 대기 시간:").pack(side=tk.LEFT)
        self.delay_seconds = ttk.Spinbox(speed_frame, from_=0, to=10, width=5)
        self.delay_seconds.pack(side=tk.LEFT, padx=5)
        self.delay_seconds.set(1)
        ttk.Label(speed_frame, text="초 (스팸 방지용)").pack(side=tk.LEFT)
        
        # 5. 전송 버튼 및 상태
        control_frame = ttk.Frame(main_frame)
        control_frame.grid(row=4, column=0, columnspan=2, pady=10)
        
        ttk.Button(control_frame, text="✉️  메일 전송 시작", 
                  command=self.send_emails, 
                  style="Accent.TButton").pack(side=tk.LEFT, padx=5)
        
        ttk.Button(control_frame, text="💾 설정 저장", 
                  command=self.save_config).pack(side=tk.LEFT, padx=5)
        
        ttk.Button(control_frame, text="🔍 메일 미리보기", 
                  command=self.preview_email).pack(side=tk.LEFT, padx=5)
        
        # 6. 로그/상태 표시
        log_frame = ttk.LabelFrame(main_frame, text="전송 로그", padding="5")
        log_frame.grid(row=5, column=0, columnspan=2, sticky=(tk.W, tk.E, tk.N, tk.S), pady=5)
        
        self.log_text = scrolledtext.ScrolledText(log_frame, width=70, height=8, state='disabled')
        self.log_text.pack(fill=tk.BOTH, expand=True)
        
        # 그리드 가중치 설정
        main_frame.columnconfigure(1, weight=1)
        main_frame.rowconfigure(2, weight=1)
        main_frame.rowconfigure(5, weight=1)
        content_frame.columnconfigure(1, weight=1)
        content_frame.rowconfigure(2, weight=1)
        
    def log(self, message):
        """로그 메시지 출력"""
        self.log_text.config(state='normal')
        self.log_text.insert(tk.END, message + "\n")
        self.log_text.see(tk.END)
        self.log_text.config(state='disabled')
        self.root.update()
        
    def load_recipients(self):
        """수신자 데이터 파일 불러오기"""
        file_path = filedialog.askopenfilename(
            title="수신자 데이터 파일 선택",
            filetypes=[("Excel files", "*.xlsx *.xls"), ("CSV files", "*.csv"), ("All files", "*.*")]
        )
        
        if not file_path:
            return
        
        try:
            if file_path.endswith('.csv'):
                self.recipients_data = pd.read_csv(file_path, encoding='utf-8-sig')
            else:
                self.recipients_data = pd.read_excel(file_path)
            
            self.file_label.config(
                text=f"✓ {os.path.basename(file_path)} ({len(self.recipients_data)}명)", 
                foreground="green"
            )
            self.log(f"수신자 데이터 로드 완료: {len(self.recipients_data)}명")
            self.log(f"컬럼: {', '.join(self.recipients_data.columns)}")
            
            # 필수 컬럼 확인
            required_cols = ['이메일']
            missing_cols = [col for col in required_cols if col not in self.recipients_data.columns]
            if missing_cols:
                messagebox.showwarning("컬럼 확인", 
                    f"필수 컬럼이 없습니다: {', '.join(missing_cols)}\n"
                    f"현재 컬럼: {', '.join(self.recipients_data.columns)}")
        
        except Exception as e:
            messagebox.showerror("오류", f"파일 로드 실패:\n{str(e)}")
            self.log(f"❌ 파일 로드 실패: {str(e)}")
    
    def show_variables(self):
        """사용 가능한 변수 표시"""
        if self.recipients_data is None:
            messagebox.showinfo("알림", "먼저 수신자 데이터를 불러와주세요.")
            return
        
        variables = '\n'.join([f"• {{{{   {col}   }}}}" for col in self.recipients_data.columns])
        messagebox.showinfo("사용 가능한 변수", 
            f"Excel 파일의 컬럼명을 변수로 사용할 수 있습니다:\n\n{variables}\n\n"
            "예: 안녕하세요, {{이름}}님")
    
    def preview_data(self):
        """데이터 미리보기"""
        if self.recipients_data is None:
            messagebox.showwarning("경고", "먼저 수신자 데이터를 불러와주세요.")
            return
        
        preview_window = tk.Toplevel(self.root)
        preview_window.title("데이터 미리보기")
        preview_window.geometry("900x450")
        
        frame = ttk.Frame(preview_window)
        frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        tree = ttk.Treeview(frame, show='headings')
        tree.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        
        scrollbar_y = ttk.Scrollbar(frame, orient=tk.VERTICAL, command=tree.yview)
        scrollbar_y.pack(side=tk.RIGHT, fill=tk.Y)
        tree.configure(yscrollcommand=scrollbar_y.set)
        
        scrollbar_x = ttk.Scrollbar(preview_window, orient=tk.HORIZONTAL, command=tree.xview)
        scrollbar_x.pack(fill=tk.X)
        tree.configure(xscrollcommand=scrollbar_x.set)
        
        tree['columns'] = list(self.recipients_data.columns)
        for col in self.recipients_data.columns:
            tree.heading(col, text=col)
            tree.column(col, width=150)
        
        for idx, row in self.recipients_data.head(100).iterrows():
            tree.insert('', tk.END, values=list(row))
        
        if len(self.recipients_data) > 100:
            ttk.Label(preview_window, 
                     text=f"※ 처음 100개만 표시. 전체: {len(self.recipients_data)}개",
                     foreground="blue").pack(pady=5)
    
    def preview_email(self):
        """첫 번째 수신자 기준으로 메일 미리보기"""
        if self.recipients_data is None or len(self.recipients_data) == 0:
            messagebox.showwarning("경고", "수신자 데이터를 먼저 불러와주세요.")
            return
        
        first_row = self.recipients_data.iloc[0]
        subject = self.subject.get()
        body_template = self.body_text.get(1.0, tk.END).strip()
        
        # 모든 변수 치환
        body = self.replace_variables(body_template, first_row)
        
        preview_window = tk.Toplevel(self.root)
        preview_window.title("메일 미리보기 (첫 번째 수신자)")
        preview_window.geometry("700x500")
        
        frame = ttk.Frame(preview_window, padding="10")
        frame.pack(fill=tk.BOTH, expand=True)
        
        ttk.Label(frame, text="받는 사람:", font=('', 10, 'bold')).pack(anchor=tk.W, pady=2)
        ttk.Label(frame, text=first_row.get('이메일', 'N/A')).pack(anchor=tk.W, padx=20, pady=2)
        
        ttk.Label(frame, text="제목:", font=('', 10, 'bold')).pack(anchor=tk.W, pady=2)
        ttk.Label(frame, text=subject).pack(anchor=tk.W, padx=20, pady=2)
        
        ttk.Label(frame, text="본문:", font=('', 10, 'bold')).pack(anchor=tk.W, pady=2)
        
        body_display = scrolledtext.ScrolledText(frame, width=80, height=20, wrap=tk.WORD)
        body_display.pack(fill=tk.BOTH, expand=True, pady=5)
        body_display.insert(1.0, body)
        body_display.config(state='disabled')
        
        if self.attach_files.get() and '첨부파일' in first_row:
            attachment = first_row.get('첨부파일', '')
            if attachment and not pd.isna(attachment):
                ttk.Label(frame, text=f"첨부파일: {os.path.basename(str(attachment))}", 
                         foreground="blue").pack(anchor=tk.W, pady=2)
    
    def replace_variables(self, template, row_data):
        """템플릿의 변수를 실제 데이터로 치환"""
        result = template
        
        # {{변수명}} 패턴 찾기
        pattern = r'\{\{(.*?)\}\}'
        matches = re.findall(pattern, template)
        
        for var_name in matches:
            var_name = var_name.strip()
            if var_name in row_data.index:
                value = row_data[var_name]
                # NaN 처리
                if pd.isna(value):
                    value = ''
                result = result.replace(f'{{{{{var_name}}}}}', str(value))
        
        return result
    
    def create_sample_file(self):
        """샘플 Excel 파일 생성"""
        sample_data = {
            '이메일': ['user1@example.com', 'user2@example.com', 'user3@example.com'],
            '이름': ['홍길동', '김철수', '이영희'],
            '회사명': ['A회사', 'B회사', 'C회사'],
            '부서': ['개발팀', '영업팀', '관리팀'],
            '첨부파일': ['', 'C:/files/document1.pdf', 'C:/files/document2.pdf']
        }
        
        df = pd.DataFrame(sample_data)
        
        file_path = filedialog.asksaveasfilename(
            defaultextension=".xlsx",
            filetypes=[("Excel files", "*.xlsx")],
            initialfile="샘플_수신자_데이터_고급.xlsx"
        )
        
        if file_path:
            df.to_excel(file_path, index=False)
            messagebox.showinfo("완료", 
                f"샘플 파일이 생성되었습니다:\n{file_path}\n\n"
                "모든 컬럼(회사명, 부서 등)을 {{컬럼명}} 형식으로 사용할 수 있습니다.")
            self.log(f"✓ 샘플 파일 생성: {file_path}")
    
    def show_gmail_guide(self):
        """Gmail 설정 가이드"""
        guide = """Gmail 사용 설정 가이드

1. Gmail 계정에서 2단계 인증 활성화
   - Google 계정 관리 > 보안 > 2단계 인증

2. 앱 비밀번호 생성
   - Google 계정 관리 > 보안 > 앱 비밀번호
   - 앱: 메일, 기기: Windows 컴퓨터
   - 생성된 16자리 비밀번호 복사

3. SMTP 설정
   - SMTP: smtp.gmail.com, 포트: 587

※ 앱 비밀번호 사용 필수!
※ 하루 전송 제한: 약 500통"""
        
        messagebox.showinfo("Gmail 설정 가이드", guide)
    
    def send_emails(self):
        """메일 전송"""
        if not self.validate_inputs():
            return
        
        if not self.test_mode.get():
            result = messagebox.askyesno(
                "전송 확인",
                f"총 {len(self.recipients_data)}명에게 메일을 전송합니다.\n계속하시겠습니까?"
            )
            if not result:
                return
        
        self.log("=" * 50)
        self.log(f"메일 전송 시작 - {len(self.recipients_data)}명")
        if self.test_mode.get():
            self.log("⚠️ 테스트 모드: 실제 전송 안됨")
        self.log("=" * 50)
        
        success_count = 0
        fail_count = 0
        
        smtp_conn = None
        if not self.test_mode.get():
            try:
                smtp_conn = smtplib.SMTP(self.smtp_server.get(), int(self.smtp_port.get()))
                smtp_conn.starttls()
                smtp_conn.login(self.sender_email.get(), self.sender_password.get())
                self.log("✓ SMTP 서버 연결 성공")
            except Exception as e:
                messagebox.showerror("연결 오류", f"SMTP 서버 연결 실패:\n{str(e)}")
                self.log(f"❌ SMTP 연결 실패: {str(e)}")
                return
        
        delay = float(self.delay_seconds.get())
        
        for idx, row in self.recipients_data.iterrows():
            try:
                recipient_email = row.get('이메일', '')
                recipient_name = row.get('이름', f'수신자{idx+1}')
                
                if not recipient_email or pd.isna(recipient_email):
                    self.log(f"⚠️ [{idx+1}] 이메일 주소 없음 - 건너뜀")
                    fail_count += 1
                    continue
                
                # 변수 치환
                body = self.replace_variables(self.body_text.get(1.0, tk.END).strip(), row)
                
                msg = MIMEMultipart()
                msg['From'] = self.sender_email.get()
                msg['To'] = recipient_email
                msg['Subject'] = self.subject.get()
                
                # HTML 또는 텍스트
                if self.html_mode.get():
                    # 줄바꿈을 <br>로 변환
                    body_html = body.replace('\n', '<br>\n')
                    msg.attach(MIMEText(body_html, 'html', 'utf-8'))
                else:
                    msg.attach(MIMEText(body, 'plain', 'utf-8'))
                
                # 첨부파일
                if self.attach_files.get() and '첨부파일' in row and row['첨부파일']:
                    attachment_path = row['첨부파일']
                    if not pd.isna(attachment_path) and os.path.exists(attachment_path):
                        try:
                            with open(attachment_path, 'rb') as f:
                                part = MIMEBase('application', 'octet-stream')
                                part.set_payload(f.read())
                                encoders.encode_base64(part)
                                
                                # 파일명을 UTF-8로 인코딩하여 확장자 유지
                                filename = os.path.basename(attachment_path)
                                part.add_header(
                                    'Content-Disposition',
                                    'attachment',
                                    filename=('utf-8', '', filename)
                                )
                                msg.attach(part)
                            self.log(f"  └ 첨부: {os.path.basename(attachment_path)}")
                        except Exception as e:
                            self.log(f"  └ 첨부 오류: {str(e)}")
                
                if not self.test_mode.get():
                    smtp_conn.send_message(msg)
                    self.log(f"✓ [{idx+1}] {recipient_name} ({recipient_email})")
                    if delay > 0 and idx < len(self.recipients_data) - 1:
                        time.sleep(delay)
                else:
                    self.log(f"[TEST] [{idx+1}] {recipient_name} ({recipient_email})")
                
                success_count += 1
                
            except Exception as e:
                self.log(f"❌ [{idx+1}] 실패: {str(e)}")
                fail_count += 1
        
        if smtp_conn:
            smtp_conn.quit()
        
        self.log("=" * 50)
        self.log(f"완료 - 성공: {success_count}, 실패: {fail_count}")
        self.log("=" * 50)
        
        if not self.test_mode.get():
            messagebox.showinfo("완료", 
                f"메일 전송 완료\n\n성공: {success_count}건\n실패: {fail_count}건")
        else:
            messagebox.showinfo("테스트 완료", 
                f"테스트 완료\n\n준비: {success_count}건\n오류: {fail_count}건\n\n"
                "테스트 모드를 해제하고 실제 전송하세요.")
    
    def validate_inputs(self):
        """입력 유효성 검사"""
        if not self.sender_email.get():
            messagebox.showwarning("경고", "발신 이메일을 입력하세요.")
            return False
        
        if not self.sender_password.get():
            messagebox.showwarning("경고", "비밀번호를 입력하세요.")
            return False
        
        if self.recipients_data is None:
            messagebox.showwarning("경고", "수신자 데이터를 불러오세요.")
            return False
        
        if not self.subject.get():
            messagebox.showwarning("경고", "메일 제목을 입력하세요.")
            return False
        
        return True
    
    def save_config(self):
        """설정 저장"""
        config = {
            'sender_email': self.sender_email.get(),
            'smtp_server': self.smtp_server.get(),
            'smtp_port': self.smtp_port.get()
        }
        
        try:
            with open(self.config_file, 'w', encoding='utf-8') as f:
                json.dump(config, f, ensure_ascii=False, indent=2)
            messagebox.showinfo("저장 완료", "설정이 저장되었습니다.")
            self.log("✓ 설정 저장")
        except Exception as e:
            messagebox.showerror("저장 실패", f"오류:\n{str(e)}")
    
    def load_config(self):
        """설정 불러오기"""
        try:
            if os.path.exists(self.config_file):
                with open(self.config_file, 'r', encoding='utf-8') as f:
                    self.config = json.load(f)
            else:
                self.config = {}
        except:
            self.config = {}

def main():
    root = tk.Tk()
    app = AdvancedEmailSenderApp(root)
    root.mainloop()

if __name__ == "__main__":
    main()
